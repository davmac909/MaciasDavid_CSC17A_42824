/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   PlayerOne.h
 * Author: PC
 *
 * Created on May 4, 2016, 10:18 PM
 */

#ifndef PLAYERONE_H
#define PLAYERONE_H

using namespace std;
struct PlayerOne
{
	string name;
	int health;
	int lives;
	int level;
        int health2;
};

#endif /* PLAYERONE_H */

